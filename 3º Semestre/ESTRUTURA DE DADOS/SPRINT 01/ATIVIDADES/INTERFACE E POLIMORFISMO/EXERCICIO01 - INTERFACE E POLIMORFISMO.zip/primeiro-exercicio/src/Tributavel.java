public interface Tributavel {
        double getValorTributo();
    }


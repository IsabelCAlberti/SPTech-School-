public interface iSustentabilidade {

    double getContribuicaoSustentabilidade();
}

public interface Comemoravel {
    void comemorarGol();
}

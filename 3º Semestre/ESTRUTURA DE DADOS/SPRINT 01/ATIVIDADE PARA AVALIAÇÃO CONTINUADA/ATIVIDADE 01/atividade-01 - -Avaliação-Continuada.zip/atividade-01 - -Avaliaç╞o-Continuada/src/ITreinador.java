public interface ITreinador {
    void definirEstrategia();
    void fazerSubstituicao();
    void darFeedback();
}

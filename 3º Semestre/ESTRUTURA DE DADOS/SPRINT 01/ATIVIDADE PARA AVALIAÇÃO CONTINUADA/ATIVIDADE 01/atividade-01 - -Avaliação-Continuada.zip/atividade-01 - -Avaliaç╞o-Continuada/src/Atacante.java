import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Atacante extends Jogador implements Comemoravel {
    private int numeroCamisa;

    public Atacante(String nome, int idade) {
        super(nome, idade);
    }
    String batedorPenalti;
    @Override
    public void jogar() {
        List<String> nomeJogador = new ArrayList<>(List.of("Neymar", "Robinho"));
        Scanner scanner = new Scanner(System.in);

        int rodadas = 1;
        while (rodadas <= 5) {
            // Mostra os nomes da lista
            for (int i = 0; i < nomeJogador.size(); i++) {
                System.out.printf("Jogador %d - %s\n", i + 1, nomeJogador.get(i));
            }

            // Pessoa escolhe jogador
            System.out.print("Escolha o jogador para bater o pênalti (1 ou 2): ");
            int escolha = scanner.nextInt();
            batedorPenalti = nomeJogador.get(escolha - 1);
            System.out.println("O jogador " + batedorPenalti + " está pronto para o pênalti");

            // Simula se o goleiro defendeu
            Goleiro goleiro = new Goleiro("", 0);
            String resultado = goleiro.defesa();
            System.out.println("Resultado do pênalti: " + resultado);

            // Incrementa o número de rodadas
            rodadas++;

            int placarFinal = goleiro.contGol - (goleiro.contDefesa+ goleiro.contPraFora);

            // Pergunta se deseja continuar
            if (rodadas <= 5) {
                System.out.print("Deseja continuar? (S/N): ");
                String resposta = scanner.next();
                if (!resposta.equalsIgnoreCase("S")) {
                    break;
                }
            }

            // Verifica se ocorreu gol e chama o método comemorarGol() se necessário
            String mensagem = resultado.equals("Gollllllllllllllllllll!!!") ? batedorPenalti + " está comemorando com cambalhotas o gol!" : batedorPenalti + " está lamentando o pênalti perdido!";
            System.out.println(mensagem);

            String resultadoFinal = placarFinal < 1 ? "Resultado Final: Nenhum pênalti marcado!" : "Resultado Final: " + placarFinal + " Gols";
            System.out.println(resultadoFinal);
        }
    }
    @Override
    public void comemorarGol() {
        System.out.println(batedorPenalti + " está comemorando com cambalhotas o gol!");
    }

    public int getNumeroCamisa() {
        return numeroCamisa;
    }

    public void setNumeroCamisa(int numeroCamisa) {
        this.numeroCamisa = numeroCamisa;
    }

    public String getBatedorPenalti() {
        return batedorPenalti;
    }

    public void setBatedorPenalti(String batedorPenalti) {
        this.batedorPenalti = batedorPenalti;
    }
}

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Tecnico implements ITreinador{
    List<String> estrategias = new ArrayList<>();
    private List<String> jogadores = new ArrayList<>(List.of("Cássio", "Carlos Miguel", "Matheus Donelli", "Hugo", "Diego Palácios", "Fagner", "Lucas Veríssimo", "Félix Torres", "Caetano", "Gustavo Henrique", "Maycon", "Raniele", "Fausto Vera", "Matías Rojas", "Matheus Araújo", "Yuri Alberto", "Romero", "Gustavo Mosquito"));

    @Override
    public void definirEstrategia() {
        estrategias.add("Estratégia 442");
        estrategias.add("Estratégia 4312");
        estrategias.add("Estratégia 3421");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escolha uma estratégia: ");
        for (int i = 0; i < estrategias.size(); i++) {
            System.out.println((i + 1) + ". " + estrategias.get(i));
        }
        int escolha = scanner.nextInt();
        System.out.println("O técnico definiu a seguinte estratégia: " + estrategias.get(escolha - 1));
    }


    @Override
    public void fazerSubstituicao() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Deseja fazer alguma substituição? Sim ou Não ");
        String escolhaSubstituir = scanner.next();
        if(escolhaSubstituir.equalsIgnoreCase("Sim")){
            System.out.println(getJogadores());
            System.out.println("Qual jogador irá substituir?");
            String jogadorSubstituir = scanner.next();
            if(jogadores.contains(jogadorSubstituir)){
                System.out.println("Por qual jogador você quer substituir " + jogadorSubstituir + "?");
                String novoJogador = scanner.next();
                int index = jogadores.indexOf(jogadorSubstituir);
                jogadores.set(index, novoJogador);
                System.out.println(jogadorSubstituir + " foi substituído por " + novoJogador);
            } else {
                System.out.println("O jogador " + jogadorSubstituir + " não está na lista.");
            }
        }
    }

    @Override
    public void darFeedback() {
        System.out.println("O técnico está dando feedback para o time.");
    }

    public List<String> getEstrategias() {
        return estrategias;
    }

    public void setEstrategias(List<String> estrategias) {
        this.estrategias = estrategias;
    }

    public List<String> getJogadores() {
        return jogadores;
    }

    public void setJogadores(List<String> jogadores) {
        this.jogadores = jogadores;
    }
}

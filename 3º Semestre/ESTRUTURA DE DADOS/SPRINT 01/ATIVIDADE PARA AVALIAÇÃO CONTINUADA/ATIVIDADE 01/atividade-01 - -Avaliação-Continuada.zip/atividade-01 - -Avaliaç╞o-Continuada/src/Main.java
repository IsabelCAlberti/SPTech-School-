import java.util.List;

public class Main {
    public static void main(String[] args) {

        // Criando jogadores
        Atacante atacante = new Atacante(" ", 29);
        Goleiro goleiro = new Goleiro(" ", 29);


        Tecnico tecnico = new Tecnico();
        List<String> jogadores = tecnico.getJogadores();
        System.out.println("Jogadores: " + jogadores);
        tecnico.definirEstrategia();
        tecnico.fazerSubstituicao();
        tecnico.darFeedback();

        // Chamando o método jogar dos jogadores
        goleiro.jogar();
        atacante.jogar();
    }
}

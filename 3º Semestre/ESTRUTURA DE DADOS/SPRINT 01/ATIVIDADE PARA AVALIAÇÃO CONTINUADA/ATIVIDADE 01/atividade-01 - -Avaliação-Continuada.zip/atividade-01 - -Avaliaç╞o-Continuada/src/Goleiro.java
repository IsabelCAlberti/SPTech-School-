import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Goleiro extends Jogador {
    public Goleiro(String nome, int idade) {
        super(nome, idade);
    }

    @Override
    public void jogar() {
        List<String> nomeGoleiro = new ArrayList<String>(List.of("Cássio", "Dida"));
        Scanner scanner = new Scanner(System.in);
        System.out.print("Escolha um goleiro: Cássio ou Dida?");
        String escolheGoleiro = scanner.next();
        System.out.println("O goleiro " + escolheGoleiro + " esta pronto para o penalty");
    }

    int contDefesa = 0;
    int contPraFora;
    int contGol;
    public String defesa() {
       // Assim, Math.random()*5 estará entre 0.0 e 2.999
        double deuDefesa = Math.random() * 3;
        if(deuDefesa <= 1){
            contDefesa++;
            return "Defendeu !!!!!!";
        } else if(deuDefesa > 1 & deuDefesa <=2){
            contGol++;
            return "Gollllllllllllllllllll!!!";
        } else {
            contPraFora++;
            return "Pra fora!!!!!!!";
        }
    }

    public int getContDefesa() {
        return contDefesa;
    }

    public void setContDefesa(int contDefesa) {
        this.contDefesa = contDefesa;
    }

    public int getContPraFora() {
        return contPraFora;
    }

    public void setContPraFora(int contPraFora) {
        this.contPraFora = contPraFora;
    }

    public int getContGol() {
        return contGol;
    }

    public void setContGol(int contGol) {
        this.contGol = contGol;
    }
}

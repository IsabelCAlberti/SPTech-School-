public class Ordenacao {
    public static void exibirVetorDeInteiros(int[] vetor) {
        //exibe o vetor
        for (int i = 0; i < vetor.length; i++) {
            System.out.println(vetor[i]);
        }
    }

    public static void selectionSort(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = i + 1; j < vetor.length; j++) {
                if (vetor[j] < vetor[i]) {
                    int aux = vetor[i];
                    vetor[i] = vetor[j];
                    vetor[j] = aux;
                }
            }
        }
    }

    public static void selectionSortOtimizado(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            int indiceMenor = i;
            for (int j = i + 1; j < vetor.length; j++) {
                if (vetor[j] < vetor[indiceMenor]) {
                    indiceMenor = j;
                }
            }
            int aux = vetor[i];
            vetor[i] = vetor[indiceMenor];
            vetor[indiceMenor] = aux;
        }
    }

    public static void bubbleSort(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = 1; j < vetor.length - i; j++) {
                if (vetor[j - 1] > vetor[j]) {
                    int aux = vetor[j];
                    vetor[j] = vetor[j - 1];
                    vetor[j - 1] = aux;
                }
            }
        }
    }

    public static int pesquisaBinaria(int[] vetor, int valorProcurado) {

        int indiceInferior = 0;
        int indiceSuperior = vetor.length - 1;
        while (indiceInferior <= indiceSuperior) {
            int meio = (indiceInferior + indiceSuperior) / 2;
            if (vetor[meio] == valorProcurado) {
                return meio;
            } else if (valorProcurado < vetor[meio]) {
                indiceSuperior = meio - 1;
            } else {
                indiceInferior = meio + 1;
            }

        }
        return -1;
    }

    public static void main(String[] args) {
        int[] vetor = {4, 7, 5, 2, 8, 1, 6, 3};
        int[] vetor02 = {4, 7, 5, 2, 8, 1, 6, 3};
        int[] vetor03 = {4, 7, 5, 2, 8, 1, 6, 3};
        int[] vetor04 = {15, 20, 25, 30, 35, 40, 45, 50};

        System.out.println("Selection Sort:");
        selectionSort(vetor);
        exibirVetorDeInteiros(vetor);

        System.out.println("Selection Sort Otimizado:");
        selectionSortOtimizado(vetor02);
        exibirVetorDeInteiros(vetor02);

        System.out.println("Bubble Sort Otimizado:");
        selectionSortOtimizado(vetor03);
        exibirVetorDeInteiros(vetor03);

        System.out.println("Pesquisa Binária:");
        int valorProcurado = 35;
        System.out.println("Posição do valor procurado: "
                + pesquisaBinaria(vetor04, valorProcurado));
    }

}

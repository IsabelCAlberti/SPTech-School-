[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/bu_ujg2l)
# Mini-Jogo "Caça ao Tesouro"

## Objetivo: 
Criar um jogo simples em Java onde o jogador deve encontrar tesouros escondidos em um mapa linear, utilizando conceitos de vetores para gerenciar as posições dos tesouros e das armadilhas.

## Descrição da Atividade:
### Introdução ao Jogo: 
O mapa do jogo é representado por um vetor de uma dimensão, onde cada posição pode conter um tesouro, uma armadilha, ou estar vazia. O objetivo é encontrar todos os tesouros sem cair nas armadilhas.

## Especificação do Jogo:
### Mapa: 
Um vetor de inteiros onde cada elemento representa uma posição no mapa. Valores específicos indicam tesouros, armadilhas ou espaços vazios.
### Jogadas: 
O jogador escolhe uma posição no vetor para "escavar" em busca de tesouros. Se a posição contiver um tesouro, o jogador ganha pontos. Se for uma armadilha, o jogo termina.
### Partidas e Pontuação: 
O jogo deve possuir 3 partidas, onde cada partida representa um jogador, o jogador acumula pontos por cada tesouro encontrado, a partida termina quando todos os tesouros são encontrados ou o jogador aciona uma armadilha.
### Vencedor:
Após as 3 partidas, o jogo deve indicar qual jogador venceu em primeiro, segundo e terceiro lugar

## Desafios de Programação:
### Inicialização do Mapa: 
Gerar aleatoriamente as posições dos tesouros e das armadilhas no vetor.
### Lógica do Jogo: 
Implementar a lógica para verificar as escolhas do jogador, atualizar o mapa e a pontuação, e determinar o fim do jogo.
### Interface com o Usuário:
Desenvolver uma interface simples no console para permitir que o jogador escolha posições e para mostrar o estado atual do jogo.

public interface Bonus {
    double valorBonus();
}

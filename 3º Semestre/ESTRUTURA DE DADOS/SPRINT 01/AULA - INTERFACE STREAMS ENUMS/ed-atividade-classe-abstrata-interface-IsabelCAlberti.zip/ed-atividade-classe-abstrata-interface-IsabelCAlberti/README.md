[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/vJcGpxDR)
# Exercício - Classe Abstrata ou Interface

### Observações:
- Desenhe o diagrama de classes do sistema abaixo e coloque um PRINT com o nome ```diagrama``` na pasta/diretório raiz do projeto Java
- A resposta das perguntas númeradas abaixo deve ser entregue num arquivo txt com nome ```respostas```, também adicionado na pasta/diretório raiz do projeto

## Imagine o seguinte cenário:

Uma escola tem vários funcionários.

No final de cada ano, a escola paga um bônus sobre o salário apenas dos coordenadores e dos
professores. Os demais funcionários da escola não ganham esse bônus.

Há uma regra na escola de que o coordenador não deve dar aula, e de que o professor não deve
coordenar.

### Pergunta 01) Se quisermos obrigar que a classe que representa o ```Professor``` e a classe que representa o ```Coordenador``` implementem o método: ```getValorBonus()``` qual seria a melhor forma: classe abstrata ou interface? Justifique

*Atenção:* As outras classes que representam funcionários que não recebem bônus não devem
ter esse método. Não é necessário representar no diagrama de classes nem implementar essas
outras classes. Também não há necessidade de representar nem implementar a classe Escola.

Implemente o sistema, de acordo com a sua resposta.

Implemente a classe abstrata ou a interface, o que você julgou ser mais adequado.
- Atributos de Professor: nome, quantidade de aulas por semana, valor da hora aula
- Atributos de Coordenador: nome, quantidade de horas de coordenação por semana, valor da
hora de coordenação
- Cálculo do bônus do Professor: quantidade de aulas por semana * valor da hora aula * 4.5 * 0.15
- Cálculo do bônus do Coordenador: quantidade de horas de coordenação por semana * valor da
hora de coordenação * 4.5 * 0.2

Implemente também a classe ```ControleBonus```, que terá como atributo um ou mais List para
conter todos os objetos que recebem bônus.

### Pergunta 02) É necessário ter 2 List ou apenas um na classe ```ControleBonus```? Justifique

Implemente na classe ```ControleBonus```:
- Método que adiciona o objeto ao(s) List
- Método que exibe o conteúdo do(s) List
- Método que calcula o total de bônus do(s) List

### Pergunta 03) O polimorfismo está presente nesse sistema? Justifique.
 
Não se esqueça de implementar o construtor e o toString() nas diversas classes, parecido com o
que fizemos nos exercícios.

Implemente a classe que contém o main, e dentro do main, crie objetos Professor e
Coordenador, crie objeto da classe ControleBonus, e chame seus métodos.






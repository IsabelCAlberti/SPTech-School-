[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/n5OSBZJc)
# Avaliação Continuada 02 - Prática 📎
## Orientações Gerais: 🚨
1. **Respeite** os nomes de atributos e métodos definidos no exercício.
4. **Não é necessário adicionar classes novas**, todas as classes necessária estão no projeto, sendo necessário apenas completar o código das classes ```Teste```, ```GerenciadorDeArquivo``` e ```ListaEstatica```, conforme indicado no enunciado.
5. Não é necessário completar as classes ```Produto``` e ```ListaObj```, já estão totalmente prontas.
6. As **assinaturas** de todos os métodos do projeto estão completas, sendo necessário completar apenas o corpo do método, ou seja, **não altere** os argumentos e retorno dos métodos
7. Verifique se **não** há **erros de compilação** no projeto antes de enviar.
8. **Rode os teste automátizados** para acompanhar se o código atende os requisitos solicitados

## 1) Gravação de Arquivo CSV

### Na classe ```GerenciadorArquivo```:
- Complete o método gravar arquivo, considerando que os registros devem ser gravados separados por ; (ponto e virgula)
- Os atributos devem ser gravados na mesma ordem que foram criados na classe Produto

### Na classe ```Teste```:

 - Crie uma lista do tipo ```ListaObj<Produto>``` de tamanho 6.

- Preencha a lista com os seguintes dados (pode copiar e colar no seu código, não insira dados diferentes):
  ```java
        produtos.adiciona(new Produto(100,"Potes","Cozinha",5,10.65,67));
        produtos.adiciona(new Produto(101,"Sabão em Pó","Limpeza",2,9.99,8));
        produtos.adiciona(new Produto(102,"Mouse","Eletronicos",5,80.50,10));
        produtos.adiciona(new Produto(103,"Teclado","Eletronicos",1,150.93,5));
        produtos.adiciona(new Produto(104,"Pão Francês","Padaria",3,5.33,23));
        produtos.adiciona(new Produto(105,"Brigadeiro","Padaria",4,4.10,130));
  ```
- Grave o conteúdo da lista num arquivo chamado **produtos**. Os dados dos registros devem ser gravados na **mesma ordem** em que os atributos foram declarados
- ⚠️ Você deve rodar sua classe de `Teste`, para gerar o arquivo, verifique se o arquivo foi gerado corretamente e **não exclua** ele do projeto, pois será utilizado nos testes automatizados
  
## 2) Lista e Ordenação

### Na classe ListaEstatica:

- Método **`adicionaNoIndice`**:
  - Recebe o indice onde será inserido o novo elemento (assinatura já foi definida, apenas complete o corpo do método)
  - Se a lista estiver cheia, lança uma exceção IllegalStateException.
  - Verifica se o indice é válido (se for >= zero E <= nroElem), se não for válido, lança uma exceção IllegalArgumentException.
  - Se o índice for válido, insere o novo elemento na lista, no índice desejado, se o índice for no início ou no meio da lista, deve-se deslocar os elementos para "abrir o espaço" para inserir o novo elemento.
  - Incrementa o nroElem
  - Exemplo: se a lista tiver 10, 20, 30, ao chamar adicionaNoIndice(1, 40), após a execução desse método, a lista ficará 10, 40, 20, 30
- Método **`ordena`**:
  - Implemente no corpo do método um algoritmo de ordenação de sua preferencia
  - Caso escolha o Quick Sort ou Merge Sort crie um método separado e chame ele dentro do método ordena, não altere os argumentos do método ordena



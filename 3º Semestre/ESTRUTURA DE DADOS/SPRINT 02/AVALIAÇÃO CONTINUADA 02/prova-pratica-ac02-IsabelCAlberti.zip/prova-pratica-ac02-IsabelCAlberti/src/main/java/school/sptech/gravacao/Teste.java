package school.sptech.gravacao;

import school.sptech.ordenacao.ListaEstatica;

import java.sql.SQLOutput;

public class Teste {
    public static void main(String[] args) {
        //Use essa classe para criar uma lista e grave o arquivo conforme o enunciado
        //Crie uma lista do tipo ListaObj<Produto> de tamanho 6.
        ListaObj<Produto> produtos = new ListaObj<>(6);

        produtos.adiciona(new Produto(100,"Potes","Cozinha",5,10.65,67));
        produtos.adiciona(new Produto(101,"Sabão em Pó","Limpeza",2,9.99,8));
        produtos.adiciona(new Produto(102,"Mouse","Eletronicos",5,80.50,10));
        produtos.adiciona(new Produto(103,"Teclado","Eletronicos",1,150.93,5));
        produtos.adiciona(new Produto(104,"Pão Francês","Padaria",3,5.33,23));
        produtos.adiciona(new Produto(105,"Brigadeiro","Padaria",4,4.10,130));


        //Grave o conteúdo da lista num arquivo chamado produtos.
        // Os dados dos registros devem ser gravados na mesma ordem em
        // que os atributos foram declarados

        System.out.println("Gravando Arquivos");
        GerenciadorDeArquivo.gravaArquivoCsv(produtos,"produtos");

        produtos.adiciona(new Produto(106,"Pão de Queijo","Padaria",3,5.33,23));
        produtos.adiciona(new Produto(107,"Café","Mercado",4,4.10,130));
        produtos.adiciona(new Produto(108,"Leite","Mercado",3,5.33,23));
        produtos.adiciona(new Produto(109,"Bolo de Cenoura","Padaria",4,4.10,130));

        System.out.println("Lista antes da ordenação:");
        produtos.exibe();


        System.out.println("\nLista após a ordenação:");
        produtos.exibe();


        produtos.removePeloIndice(2);

        System.out.println("\nLista após remover pelo índice 2:");
        produtos.exibe();
    }
}

package school.sptech.ordenacao;

public class Teste {
    public static void main(String[] args) {
        // Create a new ListaEstatica with capacity 10
        ListaEstatica lista = new ListaEstatica(10);

        // Add elements to the list
        lista.adiciona(50);
        lista.adiciona(30);
        lista.adiciona(70);
        lista.adiciona(10);

        // Display the list
        System.out.println("Original list:");
        lista.exibe();

        // Test busca method
        int index = lista.busca(7);
        System.out.println("Index of 7: " + index);

        // Test removePeloIndice method
        boolean remover = lista.removePeloIndice(1);
        System.out.println("Removed at index 1: " + remover);

        // Display the list after removal
        System.out.println("List after removal:");
        lista.exibe();

        // Test removeElemento method
        remover = lista.removeElemento(5);
        System.out.println("Removendo elemento 5: " + remover);

        // Display the list after removal
        System.out.println("Lista após remover elemento:");
        lista.exibe();

        // Test adicionaNoIndice method
        lista.adicionaNoIndice(1, 9);
        System.out.println("Lista após adicionar pelo indice:");
        lista.exibe();

        // Test ordena method
        lista.ordena();
        System.out.println("Lista após ordenação:");
        lista.exibe();
    }
}

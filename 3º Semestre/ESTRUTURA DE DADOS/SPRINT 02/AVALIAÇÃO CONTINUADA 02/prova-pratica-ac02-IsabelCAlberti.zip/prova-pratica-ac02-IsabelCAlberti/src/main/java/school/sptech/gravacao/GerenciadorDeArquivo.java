package school.sptech.gravacao;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.Scanner;

public class GerenciadorDeArquivo {
    public static void gravaArquivoCsv(ListaObj<Produto> lista, String nomeArq) {
        FileWriter arq = null;
        Formatter saida = null;
        Boolean deuRuim = false;

        nomeArq += ".csv";

        try {
            arq = new FileWriter(nomeArq);
            saida = new Formatter(arq);
        } catch (IOException erro) {
            System.out.println("Erro ao abrir o arquivo");
            System.exit(1);
        }

        try {
            for (int i = 0; i < lista.getTamanho(); i++) {
                //Recupere um elemento da lista e formate com delimitador aqui:
                Produto produto = lista.getElemento(i);
                saida.format("%d;%s;%s;%d;%.2f;%d\n", // "ID;NOME;CATEGORIA;PONTUACAO;PRECO;QUANTIDADE_ESTOQUE\n
                        produto.getId(),
                        produto.getNome(),
                        produto.getCategoria(),
                        produto.getPontuacao(),
                        produto.getPreco(),
                produto.getQuantidadeEstoque());
            }
        } catch (FormatterClosedException erro) {
            System.out.println("Erro ao gravar o arquivo");
            deuRuim = true;
        } finally {
            saida.close();
            try {
                arq.close();
            } catch (IOException erro) {
                System.out.println("Erro ao fechar o arquivo");
                deuRuim = true;
            }
            if (deuRuim) {
                System.exit(1);
            }
        }
    }

}

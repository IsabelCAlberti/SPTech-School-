package school.sptech;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import school.sptech.gravacao.ListaObj;
import school.sptech.gravacao.Produto;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

@DisplayName("Cria arquivo CSV")
public class GravaArquivoTest {

    @Test
    @DisplayName("Arquivo criado e valores inseridos corretamente")
    public void grava() {
        FileReader arq = null;
        Scanner entrada = null;
        Boolean deuRuim = false;

        try {
            arq = new FileReader("produtos.csv");
            entrada = new Scanner(arq).useDelimiter(";|\\n");
        } catch (FileNotFoundException erro) {
            System.exit(1);
        }

        try {
            ListaObj<Produto> produtos = new ListaObj<>(6);

            while (entrada.hasNext()) {

                int id = entrada.nextInt();
                String nome = entrada.next();
                String categoria = entrada.next();
                int pontuacao = entrada.nextInt();
                double preco = entrada.nextDouble();
                int estoque = entrada.nextInt();

                produtos.adiciona(new Produto(id, nome, categoria,pontuacao,preco,estoque));
            }

            Assertions.assertEquals(100, produtos.getElemento(0).getId());
            Assertions.assertEquals("Potes", produtos.getElemento(0).getNome());
            Assertions.assertEquals("Cozinha", produtos.getElemento(0).getCategoria());
            Assertions.assertEquals(5, produtos.getElemento(0).getPontuacao());
            Assertions.assertEquals(10.65, produtos.getElemento(0).getPreco());
            Assertions.assertEquals(67, produtos.getElemento(0).getQuantidadeEstoque());

            Assertions.assertEquals(105, produtos.getElemento(5).getId());



        } catch (NoSuchElementException erro) {
            deuRuim = true;
        } catch (IllegalStateException erro) {
            deuRuim = true;
        } finally {
            entrada.close();
            try {
                arq.close();
            } catch (IOException erro) {
                deuRuim = true;
            }
            if (deuRuim) {
                System.exit(1);
            }
        }
    }
}

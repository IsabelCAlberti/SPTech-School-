package school.sptech;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import school.sptech.ordenacao.ListaEstatica;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Adiciona no Indice")
public class AdicionaNoIndiceTest {

    @Test
    @DisplayName("O elemento deve ser adicionado no indice correto")
    public void adiciona() {
        ListaEstatica lista = new ListaEstatica(5);
        lista.adiciona(10);
        lista.adiciona(20);
        lista.adiciona(30);
        lista.adiciona(40);

        lista.adicionaNoIndice(2,42);

        assertEquals(42, lista.getVetor()[2]);
        assertEquals(30, lista.getVetor()[3]);
    }

    @Test
    @DisplayName("Os elementos seguintes devem ser reposicionados")
    public void reposiciona() {
        ListaEstatica lista = new ListaEstatica(5);
        lista.adiciona(10);
        lista.adiciona(20);
        lista.adiciona(30);
        lista.adiciona(40);

        lista.adicionaNoIndice(2,42);

        assertEquals(30, lista.getVetor()[3]);
        assertEquals(40, lista.getVetor()[4]);
    }

    @Test
    @DisplayName("Deve lançar IllegalStateException quando a lista estiver cheia")
    public void adicionaListaCheia() {
        ListaEstatica lista = new ListaEstatica(5);
        lista.adiciona(10);
        lista.adiciona(20);
        lista.adiciona(30);
        lista.adiciona(40);
        lista.adiciona(40);

        assertThrows(IllegalStateException.class, () -> lista.adicionaNoIndice(2,42));

    }
    @Test
    @DisplayName("Deve lançar IllegalArgumentException quando o índice for inválido")
    public void adicionaIndiceInvalido() {
        ListaEstatica lista = new ListaEstatica(5);
        lista.adiciona(10);
        lista.adiciona(20);
        lista.adiciona(30);
        lista.adiciona(40);

        assertThrows(IllegalArgumentException.class, () -> lista.adicionaNoIndice(100,42));

    }
}

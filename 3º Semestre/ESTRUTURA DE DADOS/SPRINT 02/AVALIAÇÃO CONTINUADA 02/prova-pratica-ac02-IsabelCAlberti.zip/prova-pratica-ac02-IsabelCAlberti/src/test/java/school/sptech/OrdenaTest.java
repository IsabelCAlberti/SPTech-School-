package school.sptech;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import school.sptech.ordenacao.ListaEstatica;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Ordenação")
public class OrdenaTest {

    @Test
    @DisplayName("O vetor deve estar ordenado após a chamada do método")
    public void ordena() {
        ListaEstatica lista = new ListaEstatica(5);
        lista.adiciona(30);
        lista.adiciona(2);
        lista.adiciona(6);
        lista.adiciona(1);
        lista.adiciona(10);

        lista.ordena();

        assertEquals(1, lista.getVetor()[0]);
        assertEquals(2, lista.getVetor()[1]);
        assertEquals(6, lista.getVetor()[2]);
        assertEquals(10, lista.getVetor()[3]);
        assertEquals(30, lista.getVetor()[4]);
    }

    @Test
    @DisplayName("Deve ordenar corretamente quando lista não estiver cheia")
    public void ordenaListaNaoCheia() {
        ListaEstatica lista = new ListaEstatica(10);
        lista.adiciona(40);
        lista.adiciona(7);
        lista.adiciona(9);
        lista.adiciona(2);
        lista.adiciona(30);
        lista.adiciona(25);

        lista.ordena();

        assertEquals(2, lista.getVetor()[0]);
        assertEquals(7, lista.getVetor()[1]);
        assertEquals(9, lista.getVetor()[2]);
        assertEquals(25, lista.getVetor()[3]);
        assertEquals(30, lista.getVetor()[4]);
        assertEquals(40, lista.getVetor()[5]);
    }
}

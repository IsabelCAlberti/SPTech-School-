package Exercicio04;

public class Exercicio04 {
    //4. Dado um vetor de inteiros, devolve a quantidade de elementos ímpares que há no vetor.
    // Ex: No vetor do exemplo anterior, a quantidade de ímpares é 3.
    public static int contarImpares(int[] vetor, int tam) {
        if (tam == 0) {
        return 0;
    } else if(vetor[tam-1] % 2 != 0) {
            return vetor[tam];
    }
        return contarImpares(vetor, tam-1 );
    }
}

package Exercicio01;

public class Teste {
    public static void main(String[] args) {

        Exercicio01 exercicio01 = new Exercicio01();
        System.out.println("Soma recursiva de 5: " + exercicio01.somaComRecursiva(5));
            }
        }
